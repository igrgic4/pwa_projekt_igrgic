CREATE DATABASE news;
GO

USE news;
CREATE TABLE news (
    id INT PRIMARY KEY IDENTITY(1,1),
    naslov NVARCHAR(255) NOT NULL,
    sazetak NVARCHAR(255) NOT NULL,
    tekst NVARCHAR(MAX) NOT NULL,
    kategorija NVARCHAR(50) NOT NULL,
    slika NVARCHAR(255),
    prikazi BIT
);
GO


CREATE TABLE korisnik (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ime VARCHAR(50) NOT NULL,
    prezime VARCHAR(50) NOT NULL,
    korisnicko_ime VARCHAR(50) NOT NULL UNIQUE,O
    lozinka VARCHAR(255) NOT NULL,
    razina ENUM('korisnik', 'administrator') NOT NULL
);

GO