<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registracija korisnika</title>
</head>
<body>
    <h2>Registracija korisnika</h2>
    <form action="register.php" method="post">
        <label for="ime">Ime:</label>
        <input type="text" id="ime" name="ime" required><br><br>

        <label for="prezime">Prezime:</label>
        <input type="text" id="prezime" name="prezime" required><br><br>

        <label for="korisnicko_ime">Korisničko ime:</label>
        <input type="text" id="korisnicko_ime" name="korisnicko_ime" required><br><br>

        <label for="lozinka">Lozinka:</label>
        <input type="password" id="lozinka" name="lozinka" required><br><br>

        <label for="razina">Razina:</label>
        <select id="razina" name="razina">
            <option value="korisnik">Korisnik</option>
            <option value="administrator">Administrator</option>
        </select><br><br>

        <button type="submit">Registriraj se</button>
    </form>
</body>
</html>
