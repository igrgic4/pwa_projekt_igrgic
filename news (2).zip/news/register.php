<?php
// Povezivanje s bazom podataka
$servername = "IVANKA-PC";
$username = "sa";
$password = "nemkbo";
$dbname = "news";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Povezivanje nije uspjelo: " . $conn->connect_error);
}


$ime = $_POST['ime'];
$prezime = $_POST['prezime'];
$korisnicko_ime = $_POST['korisnicko_ime'];
$lozinka = $_POST['lozinka'];
$razina = $_POST['razina'];


$sql = "SELECT id FROM korisnik WHERE korisnicko_ime = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $korisnicko_ime);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo "Korisnik s tim korisničkim imenom već postoji.";
} else {
    
    $hashed_password = password_hash($lozinka, PASSWORD_DEFAULT);

    /
    $sql = "INSERT INTO korisnik (ime, prezime, korisnicko_ime, lozinka, razina) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $ime, $prezime, $korisnicko_ime, $hashed_password, $razina);

    if ($stmt->execute()) {
        echo "Registracija je uspješna.";
    } else {
        echo "Greška: " . $sql . "<br>" . $conn->error;
    }
}

$stmt->close();
$conn->close();
?>
