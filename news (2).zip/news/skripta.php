<?php
// Podaci za povezivanje s bazom podataka
$serverName = "IVANKA-PC"; 
$connectionOptions = array(
    "Database" => "news",
    "Uid" => "sa", 
    "PWD" => "nemkbo"  
);


$conn = sqlsrv_connect($serverName, $connectionOptions);

if ($conn === false) {
    die(print_r(sqlsrv_errors(), true));
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $naslov = $_POST['naslov'];
    $sazetak = $_POST['sazetak'];
    $tekst = $_POST['tekst'];
    $kategorija = $_POST['kategorija'];
    $prikazi = isset($_POST['prikazi']) ? 1 : 0;


    $slika = null;
    if (isset($_FILES['slika']) && $_FILES['slika']['error'] == 0) {
        $uploadDir = 'uploads/';
        $uploadFile = $uploadDir . basename($_FILES['slika']['name']);
        if (move_uploaded_file($_FILES['slika']['tmp_name'], $uploadFile)) {
            $slika = $uploadFile;
        }
    }

    $sql = "INSERT INTO news (naslov, sazetak, tekst, kategorija, slika, prikazi) VALUES (?, ?, ?, ?, ?, ?)";
    $params = array($naslov, $sazetak, $tekst, $kategorija, $slika, $prikazi);

    $stmt = sqlsrv_query($conn, $sql, $params);

    if ($stmt === false) {
        die(print_r(sqlsrv_errors(), true));
    } else {
        echo "Vijest je uspješno dodana!";
    }

 
    sqlsrv_free_stmt($stmt);
    sqlsrv_close($conn);
}
?>
