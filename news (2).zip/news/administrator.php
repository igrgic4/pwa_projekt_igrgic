<?php
session_start();

if (!isset($_SESSION['korisnicko_ime'])) {
    die("Nemate pravo pristupa ovoj stranici. <a href='login.html'>Prijavite se</a>");
}

// Povezivanje s bazom podataka
$servername = "IVANKA-PC";
$username = "sa";
$password = "nemkbo";
$dbname = "news";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Povezivanje nije uspjelo: " . $conn->connect_error);
}


$korisnicko_ime = $_SESSION['korisnicko_ime'];
$sql = "SELECT razina FROM korisnik WHERE korisnicko_ime = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $korisnicko_ime);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($razina);
$stmt->fetch();

if ($razina !== 'administrator') {
    die("Nemate administratorska prava. <a href='login.html'>Prijavite se</a>");
}

echo "Dobrodošli na administratorsku stranicu, " . $korisnicko_ime;

$stmt->close();
$conn->close
