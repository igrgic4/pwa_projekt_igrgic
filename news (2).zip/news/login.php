<?php
session_start();

// Povezivanje s bazom podataka
$servername = "IVANKA-PC";
$username = "sa";
$password = "nemkbo";
$dbname = "news";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Povezivanje nije uspjelo: " . $conn->connect_error);
}


$korisnicko_ime = $_POST['korisnicko_ime'];
$lozinka = $_POST['lozinka'];


$sql = "SELECT ime, prezime, lozinka, razina FROM korisnik WHERE korisnicko_ime = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $korisnicko_ime);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    
    $stmt->bind_result($ime, $prezime, $db_lozinka, $razina);
    $stmt->fetch();
    
    
    if (password_verify($lozinka, $db_lozinka)) {
        
        $_SESSION['korisnicko_ime'] = $korisnicko_ime;

        if ($razina === 'administrator') {
            header("Location: administrator.php");
        } else {
            echo "Pozdrav, " . $ime . ". Nažalost, nemate administratorska prava.";
        }
    } else {
        
        echo "Unijeli ste pogrešno korisničko ime ili lozinku.";
    }
} else {
    
    echo "Unijeli ste pogrešno korisničko ime ili lozinku. <a href='registracija.php'>Registrirajte se</a>";
}

$stmt->close();
$conn->close();
?>
