<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RP Online - Politika</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>RP Online</h1>
        <nav>
            <a href="index.html">Početna</a>
            <a href="sport.php">Sport</a>
            <a href="politika.php">Politika</a>
            <a href="administracija.html">Administracija</a>
        </nav>
    </header>

    <section>
        <h2>Politika</h2>
        <?php
        $serverName = "IVANKA-PC"; 
        $username = "sa";   
        $password = "nemkbo";   
        $database = "news";   

        $conn = new mysqli($serverName, $username, $password, $database);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql_politika = "SELECT id, naslov, sazetak, tekst, slika FROM news WHERE kategorija = 'Politika' AND prikazi = 1 ORDER BY id DESC";
        $result_politika = $conn->query($sql_politika);

        if ($result_politika->num_rows > 0) {
            while($row = $result_politika->fetch_assoc()) {
                echo '<article>';
                echo '<a href="article.php?id=' . $row["id"] . '">';
                if (!empty($row["slika"])) {
                    echo '<img src="' . htmlspecialchars($row["slika"]) . '" alt="' . htmlspecialchars($row["naslov"]) . '">';
                }
                echo '<h3>' . htmlspecialchars($row["naslov"]) . '</h3>';
                echo '</a>';
                echo '<p>' . htmlspecialchars($row["sazetak"]) . '</p>';
                echo '</article>';
            }
        } else {
            echo "<p>Nema političkih vijesti za prikaz.</p>";
        }

        $conn->close();
        ?>
    </section>

    <footer>
        <p>Ivanka Grgić, igrgic4@tvz.hr, 2024</p>
    </footer>
</body>
</html>
